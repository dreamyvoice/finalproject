package com.example.teamproject;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toolbar;

import androidx.annotation.Nullable;

public class subpageActivity extends Activity {



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subpage_c);



    }
}
